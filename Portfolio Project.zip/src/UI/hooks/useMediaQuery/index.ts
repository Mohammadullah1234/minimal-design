export * from "./useMediaQuery";
export { default } from "./useMediaQuery";
