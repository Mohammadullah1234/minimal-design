"use client";
import createSvgIcon from "@/UI/utils/createSvgIcon";
import { minimalNavIconId } from "./iconIds";

export default createSvgIcon(
  <>
    <path
      opacity="0.4"
      fillRule="evenodd"
      clipRule="evenodd"
      d="M12 22.5C17.799 22.5 22.5 17.799 22.5 12C22.5 6.20101 17.799 1.5 12 1.5C6.20101 1.5 1.5 6.20101 1.5 12C1.5 17.799 6.20101 22.5 12 22.5ZM12 18.3C15.4794 18.3 18.3 15.4794 18.3 12C18.3 8.52061 15.4794 5.7 12 5.7C8.52061 5.7 5.7 8.52061 5.7 12C5.7 15.4794 8.52061 18.3 12 18.3Z"
      fill="currentColor"
    />
    <path
      d="M18.6028 3.01129C19.2179 2.39622 20.2151 2.39622 20.8302 3.01129C21.4453 3.62637 21.4453 4.62361 20.8302 5.23868L5.2385 20.8304C4.62342 21.4455 3.62619 21.4455 3.01111 20.8304C2.39604 20.2153 2.39604 19.2181 3.01111 18.603L18.6028 3.01129Z"
      fill="currentColor"
    />
  </>,
  `Disabled__${minimalNavIconId}`
);

