export const minimalNavIconId: string = "nav";
export const minimalStandardIconId: string = "standard";
export const minimalGlassIconId: string = "glass";
export const minimalLargeIconId: string = "large";
export const minimalNotificationIconId: string = "notification";
