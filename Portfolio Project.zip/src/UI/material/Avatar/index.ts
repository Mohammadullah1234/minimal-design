export * from "./Avatar";
export * from "./avatarClasses";
export { default as avatarClasses } from "./avatarClasses";

export { default } from "./Avatar";
