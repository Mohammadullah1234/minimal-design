export * from "./AvatarGroup";
export * from "./avatarGroupClasses";
export { default as avatarGroupClasses } from "./avatarGroupClasses";

export { default } from "./AvatarGroup";
