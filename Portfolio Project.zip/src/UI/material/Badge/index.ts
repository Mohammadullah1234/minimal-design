export * from "./Badge";
export * from "./badgeClasses";
export { default as badgeClasses } from "./badgeClasses";

export { default } from "./Badge";
