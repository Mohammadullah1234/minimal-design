export * from "./Chip";
export * from "./chipClasses";
export { default as chipClasses } from "./chipClasses";

export { default } from "./Chip";
