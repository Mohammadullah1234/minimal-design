export const colorfulProgressCardClasses = {
  title: "colorfulProgress-title",
  caption: "colorfulProgress-caption",
  icon: "cardIconSvg",
  progressValue: "progressValue-root",
  circle1: "linearCircle1-root",
  circle2: "linearCircle2-root",
};
