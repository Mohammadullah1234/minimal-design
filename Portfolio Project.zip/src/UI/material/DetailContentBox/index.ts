import DetailContentBox from "./DetailContentBox";

export * from "./DetailContentBox";
export * from "./DetailContentBoxProps";
export * from "./DetailContentBoxStyles";
export * from "./DetailContentBoxClasses";

export * from "@mui/material/Grid";
export * from "./components";

export default DetailContentBox;
