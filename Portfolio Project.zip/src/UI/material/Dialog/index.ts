export * from "./Dialog";
export * from "./dialogClasses";
export { default as dialogClasses } from "./dialogClasses";

export { default } from "./Dialog";
