export * from "./DialogContent";
export * from "./dialogContentClasses";
export { default as dialogContentClasses } from "./dialogContentClasses";

export { default } from "./DialogContent";
