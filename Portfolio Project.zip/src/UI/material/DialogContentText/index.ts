export * from "./DialogContentText";
export * from "./dialogContentTextClasses";
export { default as dialogContentTextClasses } from "./dialogContentTextClasses";

export { default } from "./DialogContentText";
