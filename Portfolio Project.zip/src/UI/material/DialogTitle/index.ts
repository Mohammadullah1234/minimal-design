export * from "./DialogTitle";
export * from "./dialogTitleClasses";
export { default as dialogTitleClasses } from "./dialogTitleClasses";

export { default } from "./DialogTitle";
