export * from "./Divider";
export * from "./dividerClasses";
export { default as dividerClasses } from "./dividerClasses";

export { default } from "./Divider";
