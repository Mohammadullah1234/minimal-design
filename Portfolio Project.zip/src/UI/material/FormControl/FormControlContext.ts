import { FormControlState as MuiFormControlState } from "@mui/material/FormControl";

export interface FormControlState extends MuiFormControlState {}
