export * from "./FormControlLabel";
export * from "./formControlLabelClasses";
export { default as formControlLabelClasses } from "./formControlLabelClasses";

export { default } from "./FormControlLabel";
