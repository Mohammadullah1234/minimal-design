import Greeting from "./Greeting";

export * from "./Greeting";
export * from "./GreetingProps";
export default Greeting;
