export * from "./Label";
export * from "./labelClasses";
export { default as labelClasses } from "./labelClasses";

export { default } from "./Label";
