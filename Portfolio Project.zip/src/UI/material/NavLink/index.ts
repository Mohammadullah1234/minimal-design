import NavLink from "./NavLink";

export * from "./NavLink";
export * from "./NavLinkProps";

export default NavLink;
