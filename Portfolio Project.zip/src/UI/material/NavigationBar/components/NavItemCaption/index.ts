import NavItemCaption from "./NavItemCaption";

export * from "./NavItemCaption";
export default NavItemCaption;
