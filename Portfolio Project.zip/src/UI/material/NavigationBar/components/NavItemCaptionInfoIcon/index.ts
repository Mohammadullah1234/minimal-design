import NavItemCaptionInfoIcon from "./NavItemCaptionInfoIcon";

export * from "./NavItemCaptionInfoIcon";
export default NavItemCaptionInfoIcon;
