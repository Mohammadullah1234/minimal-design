import NavItemIcon from "./NavItemIcon";

export * from "./NavItemIcon";

export default NavItemIcon;
