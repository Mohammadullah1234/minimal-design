export * from "./Paper";
export * from "./paperClasses";
export { default as paperClasses } from "./paperClasses";

export { default } from "./Paper";
