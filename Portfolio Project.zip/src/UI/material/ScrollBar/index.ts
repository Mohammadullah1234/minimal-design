export * from "./ScrollBar";
export * from "./scrollBarClasses";
export { default as scrollBarClasses } from "./scrollBarClasses";

export { default } from "./ScrollBar";
