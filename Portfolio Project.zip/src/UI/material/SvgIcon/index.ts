export * from "./SvgIcon";
export * from "./svgIconClasses";
export { default as svgIconClasses } from "./svgIconClasses";

export { default } from "./SvgIcon";
