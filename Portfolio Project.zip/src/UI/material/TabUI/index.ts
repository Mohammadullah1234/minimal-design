import TabUI from "./TabUI";

export * from "./TabUI";
export * from "./TabUIProps";

export * from "@mui/material/Tab";

export default TabUI;
