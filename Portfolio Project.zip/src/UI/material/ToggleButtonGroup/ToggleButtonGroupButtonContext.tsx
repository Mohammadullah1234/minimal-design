"use client";

import { ToggleButtonGroupButtonContext as MuiToggleButtonGroupButtonContext } from "@mui/material/ToggleButtonGroup";

/**
 * @ignore - internal component.
 */
const ToggleButtonGroupButtonContext = MuiToggleButtonGroupButtonContext;
export default ToggleButtonGroupButtonContext;
