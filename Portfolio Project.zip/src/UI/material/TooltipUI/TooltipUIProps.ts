import { TooltipProps } from "@mui/material/Tooltip";

export interface TooltipUIProps extends TooltipProps {}
export * from "@mui/material/Tooltip";
