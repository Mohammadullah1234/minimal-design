import TooltipUI from "./TooltipUI";

export * from "./TooltipUI";
export * from "./TooltipUIProps";
export default TooltipUI;
