export * from "./Typography";
export * from "./typographyClasses";
export { default as typographyClasses } from "./typographyClasses";

export { default } from "./Typography";
