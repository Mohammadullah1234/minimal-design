"use client";

import { SxProps, Theme } from "@/UI/styles/MuiStyles";

export function dialogContentStyles(): SxProps<Theme> {
  return {
    padding: "0 24px",
  };
}
