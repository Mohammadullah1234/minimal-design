"use client";

import { SxProps, Theme } from "@/UI/styles/MuiStyles";

export function listStyles(): SxProps<Theme> {
  return {};
}
