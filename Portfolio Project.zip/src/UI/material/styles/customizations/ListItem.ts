"use client";

import { SxProps, Theme } from "@/UI/styles/MuiStyles";

export function listItemStyles(): SxProps<Theme> {
  return {
    // paddingTop: "4px",
    // paddingBottom: "4px",
  };
}
