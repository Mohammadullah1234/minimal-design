"use client";

import { SxProps, Theme } from "@/UI/styles/MuiStyles";

export function listItemAvatarStyles(): SxProps<Theme> {
  return {};
}
