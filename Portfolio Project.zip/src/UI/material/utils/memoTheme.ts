import { unstable_memoTheme } from "@mui/material/utils";

export const memoTheme = unstable_memoTheme;
