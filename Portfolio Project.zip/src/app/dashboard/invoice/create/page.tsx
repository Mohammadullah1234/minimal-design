
import { LazyPageLoader } from "@/app/layout/minimalDashboard";

const InvoiceCreatePage = () => {
  return (
    <LazyPageLoader>
      <h1>Welcome to InvoiceCreatePage Page</h1>
    </LazyPageLoader>
  );
};

export default InvoiceCreatePage;
