
import { LazyPageLoader } from "@/app/layout/minimalDashboard";

const InvoiceDetailsPage = () => {
  return (
    <LazyPageLoader>
      <h1>Welcome to InvoiceDetailsPage Page</h1>
    </LazyPageLoader>
  );
};

export default InvoiceDetailsPage;
