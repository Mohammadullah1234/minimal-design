
import { LazyPageLoader } from "@/app/layout/minimalDashboard";

const InvoiceEditPage = () => {
  return (
    <LazyPageLoader>
      <h1>Welcome to InvoiceEditPage Page</h1>
    </LazyPageLoader>
  );
};

export default InvoiceEditPage;
