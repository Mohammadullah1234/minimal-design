
import { LazyPageLoader } from "@/app/layout/minimalDashboard";

const JobEditPage = () => {
  return (
    <LazyPageLoader>
      <h1>Welcome to JobEditPage</h1>
    </LazyPageLoader>
  );
};

export default JobEditPage;
