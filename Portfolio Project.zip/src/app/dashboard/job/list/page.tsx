import { LazyPageLoader } from "@/app/layout/minimalDashboard";

const JobList_Page = () => {
  return (
    <LazyPageLoader>
      <h1>Welcome to JobList_Page Page</h1>
    </LazyPageLoader>
  );
};

export default JobList_Page;
