export const appPieChartData = [
  { label: "Mac", value: 1000 },
  { label: "Window", value: 5000 },
  { label: "IOS", value: 3500 },
  { label: "Android", value: 7500 },
];
