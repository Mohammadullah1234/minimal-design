import MinimalDashboardLayout from "./MinimalDashboardLayout";

export * from "./data";

export * from "./LazyPageLoader";
export { default as LazyPageLoader } from "./LazyPageLoader";

export * from "./MinimalDashboardLayout";
export default MinimalDashboardLayout;
