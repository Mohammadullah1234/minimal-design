import React from "react";

const NotFound = () => {
  return <div>No page found</div>;
};

export default NotFound;
